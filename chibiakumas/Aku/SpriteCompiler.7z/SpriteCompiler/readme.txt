This program is incomplete, it is pre alpha stage.

I developled it only up to the point of 'doing the job' of completing the game, 
and am only releasing it so that people can rebuild the game if they want to.

many functions within this program do not work, or serve  no purpose as the 
tool was an experiment I was undertaking

Use at your own risk!