﻿namespace CsImageConv
{
    class globals{
        
        public static int[,] PixelMap = new int[340, 200];
        public static System.Drawing.Bitmap LastFrame=null;
        public static string RegBC = "";
        public static string RegDE = "";
        public static string RegHL = "";
        public static int DEUsed = 0;
        public static string LastDE = "";
        public static string LastHL = "";
        public static string ChunkDeBak = "";
        public static string BitmapData = "";
        public static string[] ChunkCache_Name = new string[20480];
        public static string[] ChunkCache_Data = new string[20480];
        public static string[] ChunkCache_DE = new string[20480];
        public static int[] ChunkCache_Reused = new int[20480];
        public static int ChunkCache = 0;


        public static string[] PairCache_Data = new string[20480];
        public static int PairCache_Count = 0;

        public static bool SkipNextline = false;
        public static int GlobalsDone = 0;
        public static string initdata = "org &4000" + VbX.Chr(13) + VbX.Chr(10) + "nolist" + VbX.Chr(13) + VbX.Chr(10) +
            "LD hl,&D5E1" + VbX.Chr(13) + VbX.Chr(10) + "ld (&0030),hl" + VbX.Chr(13) + VbX.Chr(10) + "LD hl,&D5D5" + VbX.Chr(13) + VbX.Chr(10) + "ld (&0032),hl" + VbX.Chr(13) + VbX.Chr(10) + "LD hl,&D5E9" + VbX.Chr(13) + VbX.Chr(10) + "ld (&0034),hl" + VbX.Chr(13) + VbX.Chr(10);
        public static System.Text.StringBuilder imagedata = new System.Text.StringBuilder();
        public static System.Text.StringBuilder globaldata = new System.Text.StringBuilder();
        public static int localnextline = 0;
        public static int localnextlinenum = -1;
        public static int MaxDePush = 5;
        public static bool DoRawBmp = false;
        public static bool[] DePushUsed = new bool[41];
        public static bool[] BitmapPushLastUsed = new bool[41];
        public static bool[] BitmapDataLastUsed = new bool[41];
        public static bool[] MultiPushDeLast = new bool[41];
        public static bool[] BitmapDataUsed = new bool[81];
        public static int[,] LastPixelMap = new int[340, 200];
        public static string AkuyouInit =
            ";read \"BootStrap.asm\"" + VbX.Chr(13) + VbX.Chr(10) +
            "ld hl,CompiledSprite_GetNxtLin" + VbX.Chr(13) + VbX.Chr(10) +
            "ld bc,CompiledSprite_GetNxtLinbc" + VbX.Chr(13) + VbX.Chr(10) +
            ";ld a,&c0" + VbX.Chr(13) + VbX.Chr(10) +
            "call Akuyou_ScreenBuffer_GetActiveScreen" + VbX.Chr(13) + VbX.Chr(10) +
            "cp &c0" + VbX.Chr(13) + VbX.Chr(10) +
            "jr Z,CompiledSprite_Buffer2" + VbX.Chr(13) + VbX.Chr(10) +
            "ld hl,CompiledSprite_GetNxtLinAlt" + VbX.Chr(13) + VbX.Chr(10) +
            "ld bc,CompiledSprite_GetNxtLinAlt" + VbX.Chr(13) + VbX.Chr(10) +
            "CompiledSprite_Buffer2:" + VbX.Chr(13) + VbX.Chr(10) +
            "ld (CompiledSprite_NextLineJump_Plus2-2),hl" + VbX.Chr(13) + VbX.Chr(10) +
            "ld (CompiledSprite_NextLineJumpbc_Plus2-2),bc" + VbX.Chr(13) + VbX.Chr(10) +
            "ld h,a" + VbX.Chr(13) + VbX.Chr(10) +
            "ld l,&50" + VbX.Chr(13) + VbX.Chr(10) +
            "ld (StackRestore_Plus2-2),sp" + VbX.Chr(13) + VbX.Chr(10) +
            "di" + VbX.Chr(13) + VbX.Chr(10) +
            "ld sp,hl" + VbX.Chr(13) + VbX.Chr(10)
        ;
        public static string AkuyouNextLine =

           "NextLine: " + VbX.Chr(13) + VbX.Chr(10) +

    "ld hl,&0850" + VbX.Chr(13) + VbX.Chr(10) +
    "add hl,sp" + VbX.Chr(13) + VbX.Chr(10) +

    "ei" + VbX.Chr(13) + VbX.Chr(10) +
    "ld sp,&0000:StackRestore_Plus2" + VbX.Chr(13) + VbX.Chr(10) +
    "di" + VbX.Chr(13) + VbX.Chr(10) +

    "ld sp,hl" + VbX.Chr(13) + VbX.Chr(10) +
    "jp CompiledSprite_GetNxtLin :CompiledSprite_NextLineJump_Plus2" + VbX.Chr(13) + VbX.Chr(10) +
    "CompiledSprite_GetNxtLin:" + VbX.Chr(13) + VbX.Chr(10) +
    "jp nc,JumpToNextLine" + VbX.Chr(13) + VbX.Chr(10) +

    "ld hl,&c050" + VbX.Chr(13) + VbX.Chr(10) +
    "add hl,sp" + VbX.Chr(13) + VbX.Chr(10) +
    "ld sp,hl" + VbX.Chr(13) + VbX.Chr(10) +
    "jp JumpToNextLine" + VbX.Chr(13) + VbX.Chr(10) +
    "CompiledSprite_GetNxtLinAlt:" + VbX.Chr(13) + VbX.Chr(10) +
    "bit 7,h" + VbX.Chr(13) + VbX.Chr(10) +
    "jp z,JumpToNextLine" + VbX.Chr(13) + VbX.Chr(10) +
    "ld hl,&c050" + VbX.Chr(13) + VbX.Chr(10) +
    "add hl,sp" + VbX.Chr(13) + VbX.Chr(10) +
    "ld sp,hl" + VbX.Chr(13) + VbX.Chr(10) +
    ";push hl" + VbX.Chr(13) + VbX.Chr(10) +
    "jp JumpToNextLine" + VbX.Chr(13) + VbX.Chr(10) +

    "JumpToNextLine: " + VbX.Chr(13) + VbX.Chr(10) +
    "LD L,(IX)" + VbX.Chr(13) + VbX.Chr(10) +
    "INC IX" + VbX.Chr(13) + VbX.Chr(10) +
    "LD H,(IX)" + VbX.Chr(13) + VbX.Chr(10) +
    "INC IX" + VbX.Chr(13) + VbX.Chr(10) +
    "JP (HL)" + VbX.Chr(13) + VbX.Chr(10)
;

        public static string AkuyouNextLineBCdisable = "CompiledSprite_GetNxtLinbc: defw &0000 :CompiledSprite_NextLineJumpBC_Plus2" + VbX.Chr(13) + VbX.Chr(10);
        public static string AkuyouNextLineBC =

       "NextLineBC: " + VbX.Chr(13) + VbX.Chr(10) +

"ld hl,&0850" + VbX.Chr(13) + VbX.Chr(10) +
"add hl,sp" + VbX.Chr(13) + VbX.Chr(10) +

"ld sp,(StackRestore_Plus2-2)" + VbX.Chr(13) + VbX.Chr(10) +
"ei" + VbX.Chr(13) + VbX.Chr(10) +
"di" + VbX.Chr(13) + VbX.Chr(10) +

"ld sp,hl" + VbX.Chr(13) + VbX.Chr(10) +
"jp CompiledSprite_GetNxtLinBC :CompiledSprite_NextLineJumpBC_Plus2" + VbX.Chr(13) + VbX.Chr(10) +
"CompiledSprite_GetNxtLinBC:" + VbX.Chr(13) + VbX.Chr(10) +
"jp nc,JumpToNextLineBC" + VbX.Chr(13) + VbX.Chr(10) +

"ld hl,&c050" + VbX.Chr(13) + VbX.Chr(10) +
"add hl,sp" + VbX.Chr(13) + VbX.Chr(10) +
"ld sp,hl" + VbX.Chr(13) + VbX.Chr(10) +
"jp JumpToNextLineBC" + VbX.Chr(13) + VbX.Chr(10) +
"CompiledSprite_GetNxtLinAltBC:" + VbX.Chr(13) + VbX.Chr(10) +
"bit 7,h" + VbX.Chr(13) + VbX.Chr(10) +
"jp z,JumpToNextLineBC" + VbX.Chr(13) + VbX.Chr(10) +
"ld hl,&c050" + VbX.Chr(13) + VbX.Chr(10) +
"add hl,sp" + VbX.Chr(13) + VbX.Chr(10) +
"ld sp,hl" + VbX.Chr(13) + VbX.Chr(10) +
";push hl" + VbX.Chr(13) + VbX.Chr(10) +
"jp JumpToNextLineBC" + VbX.Chr(13) + VbX.Chr(10) +

"JumpToNextLineBC: " + VbX.Chr(13) + VbX.Chr(10) +
"LD L,C" + VbX.Chr(13) + VbX.Chr(10) +
"LD H,B" + VbX.Chr(13) + VbX.Chr(10) +
"JP (HL)" + VbX.Chr(13) + VbX.Chr(10)
;

public static bool UseLooper=false;
public static string LooperDef =
        "LooperContinueAddress:defw LooperContinue" + VbX.Chr(13) + VbX.Chr(10) +
"Looper:" + VbX.Chr(13) + VbX.Chr(10) +

"ld b,ixh" + VbX.Chr(13) + VbX.Chr(10) +
"ld c,ixl" + VbX.Chr(13) + VbX.Chr(10) +

"LD a,(bc)" + VbX.Chr(13) + VbX.Chr(10) +
"INC bc" + VbX.Chr(13) + VbX.Chr(10) +
"ld (Looper_CountB_Plus1-1),a" + VbX.Chr(13) + VbX.Chr(10) +
"LD a,(bc)" + VbX.Chr(13) + VbX.Chr(10) +
"INC bc" + VbX.Chr(13) + VbX.Chr(10) +
"ld (Looper_CountSize_Plus1-1),a" + VbX.Chr(13) + VbX.Chr(10) +
"ld (RestoreLooperAddress_Plus2-2),bc" + VbX.Chr(13) + VbX.Chr(10) +

"LooperNextStage:" + VbX.Chr(13) + VbX.Chr(10) +
"	ld hl,&0000 :RestoreLooperAddress_Plus2" + VbX.Chr(13) + VbX.Chr(10) +
"	ld (Looper_Address_Plus2-2),hl" + VbX.Chr(13) + VbX.Chr(10) +

"	ld a,0:Looper_CountB_Plus1" + VbX.Chr(13) + VbX.Chr(10) +
"	ld (Looper_Count_Plus1-1),a" + VbX.Chr(13) + VbX.Chr(10) +


"	LooperRepeat:" + VbX.Chr(13) + VbX.Chr(10) +
"		ld hl,&0000 :Looper_Address_Plus2" + VbX.Chr(13) + VbX.Chr(10) +

"		LD c,(hl)" + VbX.Chr(13) + VbX.Chr(10) +
"		INC hl" + VbX.Chr(13) + VbX.Chr(10) +
"		LD b,(hl)" + VbX.Chr(13) + VbX.Chr(10) +
"		INC hl" + VbX.Chr(13) + VbX.Chr(10) +
"		ld (Looper_Address_Plus2-2),hl" + VbX.Chr(13) + VbX.Chr(10) +
"		ld h,b" + VbX.Chr(13) + VbX.Chr(10) +
"		ld l,c" + VbX.Chr(13) + VbX.Chr(10) +
"		ld ix,LooperContinueAddress" + VbX.Chr(13) + VbX.Chr(10) +
"		jp (hl)" + VbX.Chr(13) + VbX.Chr(10) +
"   LooperContinue:" + VbX.Chr(13) + VbX.Chr(10) +
"		ld a,0:Looper_Count_Plus1" + VbX.Chr(13) + VbX.Chr(10) +
"		dec a" + VbX.Chr(13) + VbX.Chr(10) +
"		ld (Looper_Count_Plus1-1),a" + VbX.Chr(13) + VbX.Chr(10) +
"	jp nz,LooperRepeat" + VbX.Chr(13) + VbX.Chr(10) +


"	ld a,0:Looper_CountSize_Plus1" + VbX.Chr(13) + VbX.Chr(10) +
"	dec a" + VbX.Chr(13) + VbX.Chr(10) +
"	ld (Looper_CountSize_Plus1-1),a" + VbX.Chr(13) + VbX.Chr(10) +
"jp nz,LooperNextStage" + VbX.Chr(13) + VbX.Chr(10) +

"ld ix,(Looper_Address_Plus2-2)" + VbX.Chr(13) + VbX.Chr(10) +
"LD L,(IX)" + VbX.Chr(13) + VbX.Chr(10) +
"INC IX" + VbX.Chr(13) + VbX.Chr(10) +
"LD H,(IX)" + VbX.Chr(13) + VbX.Chr(10) +
"INC IX" + VbX.Chr(13) + VbX.Chr(10) +
"JP (HL)" + VbX.Chr(13) + VbX.Chr(10);



    }
}